
Adwaita Compact Theme for Inkscape 1.0

Default GTK 3.24.17 theme compiled from source files
with "compact" flag specified in _common.scss


Installation

1. Copy entire folder "Adwaita Compact"
   to folder "%ProgramFiles%\Inkscape\share\themes"
   or to folder "%UserProfile%\AppData\Local\Themes"

2. Launch Inkscape and select theme "Adwaita Compact"
   using menu "Edit > Preferences > Interface > Theme"
   from drop-down menu under "Change GTK theme",
   then close and relauch Inkscape


About

https://github.com/GNOME/gtk/releases/tag/3.24.17
https://github.com/GNOME/gtk/tree/mainline/gtk/theme/Adwaita